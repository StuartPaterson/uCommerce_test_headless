﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ucommerce.Search;
using Ucommerce.Search.Definitions;
using Ucommerce.Search.Extensions;
using Ucommerce.Search.Facets;

namespace CourseRepository.Search
{
    public class MyProductIndexDefinition : Ucommerce.Search.Definitions.DefaultProductsIndexDefinition
    {
        public MyProductIndexDefinition():base()
        {
            this.Field(p => p["Payments"], typeof(int)).DisplayName("en-Us","Payments").Facet();
            this.Field(p => p["Deposit"], typeof(int));
            this.Field(p => p["Tag"], typeof(String));
            this.Field(p => p["Description"], typeof(String))
            .DisplayName("en-US", "Desc")
           
            .DisplayName("Desc")
            .Facet();
            this.Field(p => p.PricesInclTax["400"]).Facet().AutoRanges(5, 10);

        }
    }
}