﻿var UcommerceClientMgr = [];

UcommerceClientMgr.BaseUCommerceUrl = '/umbraco/uCommerce/';
UcommerceClientMgr.Shell = 'Umbraco8';
UcommerceClientMgr.BaseServiceUrl = "/ucommerceapi/";