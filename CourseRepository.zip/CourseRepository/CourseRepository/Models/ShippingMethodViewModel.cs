namespace Ucommerce.Masterclass.Umbraco.Models
{
    public class ShippingMethodViewModel
    {
        public string Name { get; set; }
        
        public int ShippingMethodId { get; set; }
    }
}