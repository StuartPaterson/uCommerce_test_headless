namespace Ucommerce.Masterclass.Umbraco.Models
{
    public class CountryViewModel
    {
        public string Name { get; set; }
        
        public int CountryId { get; set; }
    }
}