namespace Ucommerce.Masterclass.Umbraco.Models
{
    public class PaymentMethodViewModel
    {
        public string Name { get; set; }
        
        public int PaymentMethodId { get; set; }
    }
}