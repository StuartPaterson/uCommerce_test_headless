﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Http;
using NSwag.Annotations;
using Ucommerce.Extensions;
using Ucommerce.Headless.API.Controllers;
using Ucommerce.Headless.Application;
using Ucommerce.Headless.Infrastructure;
using Ucommerce.Headless.Mvc.ModelBinders.ClaimBinder;
using Ucommerce.Infrastructure;
using Ucommerce.Infrastructure.Logging;
using Ucommerce.Search;
using Ucommerce.Search.Models;

using Ucommerce.Api;
using Ucommerce.Masterclass.Umbraco.Models;
using Ucommerce.Masterclass.Umbraco.Extensions;
using Ucommerce.Search.Extensions;
using Ucommerce.Search.Slugs;

namespace CourseRepository.Controllers
{
    [RoutePrefix("api/v1/getProductbySKU")]
    public class HeadlessProductController : ApiController
    {

        public IUrlService UrlService => ObjectFactory.Instance.Resolve<IUrlService>();
        public ICatalogLibrary CatalogLibrary => ObjectFactory.Instance.Resolve<ICatalogLibrary>();
        public IIndex<Product> ProductsIndex => ObjectFactory.Instance.Resolve<IIndex<Product>>();


        public HeadlessProductController()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="cultureCode"></param>
        /// <param name="ProductSkuId"></param>
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetProducts([FromUri] string ProductSkuId, [FromUri] string cultureCode = null)
        {

            var culture = cultureCode != null ? new CultureInfo(cultureCode) : CultureInfo.CurrentCulture;

            try
            {
                var product =
                CatalogLibrary.GetProduct(ProductSkuId);


                if (product == null)
                {
                    return NotFound();
                }

                return Ok(product);

            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Could not find"))
                {
                    return NotFound();
                }

                return InternalServerError();
            }


        }


    }
}