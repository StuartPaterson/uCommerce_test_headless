using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Ucommerce.Api;
using Ucommerce.Masterclass.Umbraco.Models;
using Ucommerce.Search.Models;
using Ucommerce.Search.Slugs;
using Umbraco.Web.Mvc;


namespace Ucommerce.Masterclass.Umbraco.Controllers
{
    public class CategoryNavigationController : SurfaceController

    {

        public Ucommerce.Api.ICatalogLibrary CatalogLibrary => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ICatalogLibrary>();

        public Ucommerce.Api.ICatalogContext CatalogContext => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ICatalogContext>();

        public Ucommerce.Search.Slugs.IUrlService UrlService => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<Ucommerce.Search.Slugs.IUrlService>();

        public CategoryNavigationController()
        {

        }

        public ActionResult CategoryNavigation()
        {
            var model = new CategoryNavigationViewModel();

            // var categories = CatalogLibrary.GetRootCategories();
            IEnumerable<Category> categories = CatalogLibrary.GetRootCategories().ToList();
            model.Categories = MapCategories(categories);

            return View("/views/CategoryNavigation/index.cshtml", model);
        }




        /* private IList<CategoryViewModel> MapCategories(IList<Category> categories)
         {
             var models = new List<CategoryViewModel>();
             foreach (var category in categories)
             {
                 models.Add(new CategoryViewModel()
                 {
                     Guid = category.Guid,
                     Name = category.DisplayName,
                     Url = UrlService.GetUrl(CatalogContext.CurrentCatalog, new List<Category>() { category })
                 });

             }
             return models;
             throw new NotImplementedException();
         }*/

        private IList<CategoryViewModel> MapCategories(IEnumerable<Category> categoriesToMap)
        {
            var categoriesToReturn = new List<CategoryViewModel>();

            var allSubCategoryIds = categoriesToMap.SelectMany(cat => cat.Categories).Distinct().ToList();
            var subCategoriesById = CatalogLibrary.GetCategories(allSubCategoryIds).ToDictionary(cat => cat.Guid);

            foreach (var category in categoriesToMap)
            {
                var categoryViewModel = new CategoryViewModel
                {
                    Name = category.DisplayName,
                    Url = UrlService.GetUrl(CatalogContext.CurrentCatalog,
                        new[] { category })
                };
                categoryViewModel.Categories = category.Categories
                    .Where(id => subCategoriesById.ContainsKey(id))
                    .Select(id => subCategoriesById[id])
                    .Select(cat => new CategoryViewModel
                    {
                        Name = cat.DisplayName,
                        Url = UrlService.GetUrl(CatalogContext.CurrentCatalog, new[] { category, cat })
                    })
                    .ToList();

                categoriesToReturn.Add(categoryViewModel);
            }

            return categoriesToReturn;
        }
    }
}
