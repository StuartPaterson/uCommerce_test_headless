﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ucommerce.Api;
using Ucommerce.Catalog.Models;
using Ucommerce.Extensions;
using Ucommerce.Infrastructure;
using Ucommerce.Masterclass.Umbraco.Extensions;
using Ucommerce.Masterclass.Umbraco.Models;
using Ucommerce.Search;
using Ucommerce.Search.Extensions;
using Ucommerce.Search.Facets;
using Ucommerce.Search.Models;
using Ucommerce.Search.Slugs;
using Umbraco.Core;
using Umbraco.Web.Mvc;

namespace Ucommerce.Masterclass.Umbraco.Controllers
{

    // public static class FacetedQueryStringExtensions

    public static class FacetedQueryStringExtensions
    {

       /* public static IList<Facet> ToFacets(this NameValueCollection target)
        {
            var productDefinition = ObjectFactory.Instance.Resolve<Ucommerce.Search.IIndexDefinition<Ucommerce.Search.Models.Product>>();
            var facets = productDefinition.Facets.Select(x => new KeyValuePair<string, string>(x.Key, x.Value.ToString())).ToDictionary(x => x.Key, x => x.Value);
            string[] facetsKeys = new string[facets.Keys.Count];

            facets.Keys.CopyTo(facetsKeys, 0);

            var parameters = new Dictionary<string, string>();

            foreach (var queryString in HttpContext.Current.Request.QueryString.AllKeys)
            {
                parameters[queryString] = HttpContext.Current.Request.QueryString[queryString];
            }

            parameters.RemoveAll(p => !facetsKeys.Contains(p.Key));

            var facetsForQuerying = new List<Facet>();

            foreach (var parameter in parameters)
            {
                var facet = new Facet { FacetValues = new List<FacetValue>(), Name = parameter.Key };
                foreach (var value in parameter.Value.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    facet.FacetValues.Add(new FacetValue() { Value = value });
                }


                facetsForQuerying.Add(facet);
            }

            return facetsForQuerying;
        }*/
    }

    public class CategoryController : RenderMvcController
    {

        public Ucommerce.Api.ICatalogLibrary CatalogLibrary => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ICatalogLibrary>();

        public Ucommerce.Api.ICatalogContext CatalogContext => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ICatalogContext>();

        public Ucommerce.Search.Slugs.IUrlService UrlService => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<Ucommerce.Search.Slugs.IUrlService>();
        public CategoryController()
        {

        }

        [System.Web.Mvc.HttpGet]
        public ActionResult Index()
        {
            var categoryModel = new CategoryViewModel();

            Ucommerce.Search.Models.Category  currentCategory = CatalogContext.CurrentCategory;

            var facetDictionary = System.Web.HttpContext.Current.Request.QueryString.ToFacets().ToFacetDictionary();

            Ucommerce.Search.Facets.FacetResultSet<Product> facetResultSet = CatalogLibrary.GetProducts(currentCategory.Guid, facetDictionary, 0, 300);

            categoryModel.Products = MapProducts(facetResultSet.Results);
            //categoryModel.Facets = MapFacets(facetResultSet.Facets);
            
            
   
            return View("/views/category/index.cshtml", categoryModel);
        }


        /*private IList<FacetsViewModel> MapFacets(IList<Facet>facets)
        {
            var facetsToReturn = new List<FacetsViewModel>();

            foreach(var facet in facets)
            {
                var facetsViewModel = new FacetsViewModel();
                facetsViewModel.Key = facet.Name;
                facetsViewModel.DisplayName = facet.DisplayName;

                foreach(var facetFacetValue in facet.FacetValues)
                {
                    facetsViewModel.FacetValues.Add(new FacetValueViewModel()
                    {
                        Count = facetFacetValue.Count,
                        Key = facetFacetValue.Value

                    });
                }
                facetsToReturn.Add(facetsViewModel);

            }

            return facetsToReturn;

        }*/

        /*    private IList<ProductViewModel> MapProducts(IList<Product> products)
            {


               // ProductPriceCalculationResult.Item productPrice = product.Prices.First(x => x.VariantSku == null);
                ProductPriceCalculationResult prices = CatalogLibrary.CalculatePrices(products.Select(x => x.Guid).ToList(), null);

                var listToReturn = new List<ProductViewModel>();

                foreach( var product in products)
                {
                    var productToAdd = new ProductViewModel();

                    productToAdd.LongDescription = product.LongDescription;

                    productToAdd.Name = product.DisplayName;

                      productToAdd.Prices = prices.Items.Where(x => 
                       x.ProductGuid == product.Guid && x.PriceGroupGuid== CatalogContext.CurrentPriceGroup.Guid).ToList();
                       productToAdd.Url = UrlService.GetUrl(CatalogContext.CurrentCatalog,
                           new []{CatalogContext.CurrentCategory}, product);

                   // productToAdd.Prices = "100";
                    productToAdd.Sku = product.Sku;
                    productToAdd.Sellable = product.ProductType == ProductType.Product ||
                        product.ProductType == ProductType.ProductFamily;
                    listToReturn.Add(productToAdd);
                }
                return listToReturn;

            }
        }
        */


        private IList<ProductViewModel> MapProducts(ICollection<Product> productsInCategory)
        {
            IList<ProductViewModel> productViews = new List<ProductViewModel>();

          
            var currencyIsoCode = CatalogContext.CurrentPriceGroup.CurrencyISOCode;
            foreach (var product in productsInCategory)
            {
                product.PricesInclTax.TryGetValue(CatalogContext.CurrentPriceGroup.Name, out var price);
                product.Taxes.TryGetValue(CatalogContext.CurrentPriceGroup.Name, out var tax);



                var productViewModel = new ProductViewModel
                {
                    Sku = product.Sku,
                    Name = product.DisplayName,

                    Url = UrlService.GetUrl(CatalogContext.CurrentCatalog,
                           new[] { CatalogContext.CurrentCategory }, product),
                    Price = price > 0 ? new Money(price, currencyIsoCode).ToString() : "",
                    Sellable = true,
                    Deposit = "20", // hardcoded value
                    Discount ="Up to 28% off"
                    
                   
                };

                productViews.Add(productViewModel);
            }

            return productViews;
        }


        private IList<ProductViewModel> MapProductsInCategories(Category category, out int totalProducts)
        {

            var page = Request.QueryString["pg"] ?? "1";
            var pageSize = Request.QueryString["size"] ?? "12";
            var skip = (Int32.Parse(pageSize) * Int32.Parse(page) - Int32.Parse(pageSize));

            IList<Facet> facetsForQuerying = System.Web.HttpContext.Current.Request.QueryString.ToFacets();
            var productsInCategory = new List<ProductViewModel>();


            var subCategories = CatalogLibrary.GetCategories(category.Categories);
            var products =
                CatalogLibrary.GetProducts(category.Categories.Append(category.Guid).ToList(),
                    facetsForQuerying.ToFacetDictionary());

            foreach (var subCategory in subCategories)
            {
                var productsInSubCategory = products.Where(p => p.Categories.Contains(subCategory.Guid));
                productsInCategory.AddRange(MapProducts(productsInSubCategory.ToList()));
            }

            productsInCategory.AddRange(MapProducts(products.Where(p => p.Categories.Contains(category.Guid))
                .ToList()));

            totalProducts = productsInCategory.Count;
            productsInCategory = productsInCategory.Skip(skip).Take(Int32.Parse(pageSize)).ToList();

            return productsInCategory;
        }

    }

}