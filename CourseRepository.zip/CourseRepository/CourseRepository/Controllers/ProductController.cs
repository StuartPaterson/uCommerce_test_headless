﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Ucommerce.Api;
using Ucommerce.Infrastructure;
using Ucommerce.Masterclass.Umbraco.Models;
using Ucommerce.Search;
using Ucommerce.Search.Models;
using Umbraco.Web.Mvc;

namespace Ucommerce.Masterclass.Umbraco.Controllers
{

    public class ProductController : RenderMvcController
    {

        public Ucommerce.Api.ICatalogContext CatalogContext => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ICatalogContext>();

        public Ucommerce.Api.ICatalogLibrary CatalogLibrary => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ICatalogLibrary>();


        public Ucommerce.Api.ITransactionLibrary TransactionLibrary => Ucommerce.Infrastructure.ObjectFactory.Instance.Resolve<ITransactionLibrary>();






        public ProductController()
        {

        }

        [System.Web.Mvc.HttpGet]
        public ActionResult Index()
        {
            Ucommerce.Search.Models.Product currentProduct = CatalogContext.CurrentProduct;


            var productModel = new ProductViewModel();

            productModel.Sku = currentProduct.Sku;
            productModel.Name = currentProduct.DisplayName;
            productModel.PrimaryImageUrl = currentProduct.PrimaryImageUrl;

            productModel.Prices = CatalogLibrary.CalculatePrices(new List<Guid>() { currentProduct.Guid }).Items;




            return View(productModel);
        }

        [System.Web.Mvc.HttpPost]
        public ActionResult Index(string sku, string variantSku, int quantity)
        {
            TransactionLibrary.AddToBasket(quantity, sku);

            return Index();
        }

        private IList<ProductViewModel> MapVariants(ResultSet<Product> variants)
        {
            throw new NotImplementedException();
        }
    }
}